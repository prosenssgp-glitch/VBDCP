VBDCP Android App

This is a native Android WebView shell containing the VBDCP web app locally.
The HTML/CSS/JS runs from the APK assets, not from vbdcp.netlify.app.
Firebase/online services are used only as backend/network services.

Build: GitHub Actions workflow .github/workflows/build-apk.yml
Artifact: VBDCP-debug-apk -> app-debug.apk
